-- Creazione del database
CREATE DATABASE ToysGroup;

-- Utilizzo del database
USE ToysGroup;

-- Creazione della tabella 'Category' per rappresentare le categorie dei prodotti
CREATE TABLE Category (
    category_ID INTEGER PRIMARY KEY,
    category_Name VARCHAR(255) NOT NULL
);

-- Creazione della tabella 'Product' per rappresentare i prodotti
CREATE TABLE Product (
    product_ID INTEGER PRIMARY KEY,
    product_Name VARCHAR(255) NOT NULL,
    price VARCHAR(255),
    category_ID INTEGER,
    FOREIGN KEY (category_ID) REFERENCES Category(category_ID)
);

-- Creazione della tabella 'Regions' per rappresentare le regioni degli Stati
CREATE TABLE Regions (
    region_ID INTEGER PRIMARY KEY,
    region_Name VARCHAR(255) NOT NULL
);

-- Creazione della tabella 'States' per rappresentare gli stati appartenenti alle regioni
CREATE TABLE States (
    state_ID INTEGER PRIMARY KEY,
    state_Name VARCHAR(255) NOT NULL,
    region_ID INTEGER,
    FOREIGN KEY (region_ID) REFERENCES Regions(region_ID)
);

-- Creazione della tabella 'Sales' per rappresentare le transazioni di vendita
CREATE TABLE Sales (
    sale_ID INTEGER PRIMARY KEY,
    product_ID INTEGER,
    region_ID INTEGER,
    sale_date DATE,
    quantity_sold INTEGER,
    total_amount DECIMAL(10, 2),
    FOREIGN KEY (product_id) REFERENCES Product(product_id),
    FOREIGN KEY (region_id) REFERENCES Regions(region_id)
);

-- Inserimento delle categorie dei giocattoli
INSERT INTO Category (category_ID, category_Name) VALUES
(1, 'Giocattoli per Bambini'),
(2, 'Giochi da Tavolo'),
(3, 'Action Figures'),
(4, 'Peluche');

-- Inserimento dei giocattoli all'interno di 'Product'
INSERT INTO Product (product_ID, product_Name, price, category_ID) VALUES
(1, 'Puzzle', 20.00, 2),
(2, 'Aereo Tekecommandato', 40.00, 1),
(3, 'Bambole', 40.00, 3),
(4, 'Orso di Peluche Gigante', 50.00, 4),
(5, 'Trenino Elettrico', 60.00, 1),
(6, 'Guerriero Action Figure', 25.00, 3),
(7, 'Risiko', 35.00, 2),
(8, 'Unicorno di Peluche', 20.00, 4),
(9, 'Robot Telecomandato', 45.00, 1),
(10, 'Cavaliere Action Figure', 25.00, 3),
(11, 'Scacchi', 30.00, 2),
(12, 'Dinosauro di Peluche', 35.00, 4);

-- Inserimento delle regioni del mondo
INSERT INTO Regions (region_ID, region_Name) VALUES
(1, 'WestEurope'),
(2, 'SouthEurope'),
(3, 'NorthAmerica'),
(4, 'Asia');

-- Inserimento degli Stati
INSERT INTO States (state_id, state_name, region_id) VALUES
(1, 'Francia', 1),
(2, 'Italia', 2),  
(3, 'USA', 3),
(4, 'Cina', 4);

-- Inserimento delle transazioni di vendita
INSERT INTO Sales (sale_id, product_id, region_id, sale_date, quantity_sold, total_amount) VALUES
(1, 1, 1, '2022-01-1', 100, 2000.00),
(2, 2, 2, '2023-02-2', 150, 6000.00),
(3, 3, 3, '2024-03-3', 200, 8000.00),
(4, 4, 4, '2022-04-4', 100, 5000.00),
(5, 5, 1, '2023-05-5', 150, 9000.00),
(6, 6, 2, '2024-06-6', 200, 5000.00),
(7, 7, 3, '2022-07-7', 100, 3500.00),
(8, 8, 4, '2023-08-8', 150, 3000.00),
(9, 9, 1, '2024-09-9', 200, 9000.00),
(10, 10, 2, '2022-10-10', 100, 2500.00),
(11, 11, 3, '2023-11-11', 150, 4500.00),
(12, 12, 4, '2024-12-12', 200, 7000.00);



-- 1. Verifica che le tutte le PK siano univoche

SELECT category_ID, COUNT(*)
FROM Category
GROUP BY category_ID
HAVING COUNT(*) > 1;

SELECT product_ID, COUNT(*)
FROM Product
GROUP BY product_ID
HAVING COUNT(*) > 1;

SELECT region_ID, COUNT(*)
FROM Region
GROUP BY region_ID
HAVING COUNT(*) > 1;

SELECT state_ID, COUNT(*)
FROM State
GROUP BY state_ID
HAVING COUNT(*) > 1;

SELECT sale_ID, COUNT(*)
FROM Sales
GROUP BY sale_ID
HAVING COUNT(*) > 1;

-- 2. Esposizione dei prodotti venduti e il fatturtato totale per anno.

SELECT P.product_ID, P.product_Name,
    YEAR(S.sale_date) AS sale_year,
    SUM(S.total_amount) AS total_revenue
FROM Product AS P
JOIN Sales AS S ON P.product_ID = S.product_ID
GROUP BY P.product_ID, P.product_name, YEAR(S.sale_date)
ORDER BY P.product_ID, sale_year;

-- 3. Esposizione del fatturato totale per stato per anno, il risultato ordinato per data e fatturato in modo descrescente.

SELECT YEAR(sale_date) AS anno,
    state_Name AS stato,
    SUM(total_amount) AS fatturato_totale
FROM Sales
JOIN States ON Sales.region_ID = States.region_ID
GROUP BY anno, stato
ORDER BY anno, fatturato_totale DESC, stato;

-- 4. Esposizione della categoria di giocattolo più richiesto

SELECT C.category_ID, C.category_Name,
    SUM(S.total_amount) AS total_revenue
FROM Category AS C
JOIN Product AS P ON C.category_ID = P.category_ID
LEFT JOIN Sales AS S ON P.product_ID = S.product_ID
GROUP BY C.category_ID, C.category_Name
ORDER BY total_revenue DESC;

-- 5. Esposizione dei prodotti invenduti, con 2 approcci

SELECT P.product_ID, P.product_Name
FROM Product AS P
LEFT JOIN Sales AS S ON P.product_ID = S.product_ID
WHERE S.product_ID IS NULL;

-- 2° Approccio

SELECT P.product_ID, P.product_Name
FROM Product AS P
WHERE NOT EXISTS (
        SELECT 1
        FROM Sales AS S
        WHERE P.product_ID = S.product_ID
    );

-- Esposizione dei prodotti in ordine di data descresnte

SELECT P.product_ID, P.product_Name,
    MAX(S.sale_date) AS last_sale_date
FROM Product AS P
LEFT JOIN Sales AS S ON P.product_ID = S.product_ID
GROUP BY P.product_ID, P.product_Name
ORDER BY last_sale_date DESC;

